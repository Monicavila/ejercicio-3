import React from "react";

export function Sidebar(props) {
  return <div className="sidebar"></div>;
}
