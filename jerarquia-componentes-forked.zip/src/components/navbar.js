import React from "react";

/* Importar los componentes */

/* Importar los iconos */

export default function Navbar(props) {
  return <div className="navbar"></div>;
}
