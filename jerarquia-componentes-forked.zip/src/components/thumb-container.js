import React from "react";

export function ThumbContainer() {
  return <div className="thumb-container"></div>;
}
